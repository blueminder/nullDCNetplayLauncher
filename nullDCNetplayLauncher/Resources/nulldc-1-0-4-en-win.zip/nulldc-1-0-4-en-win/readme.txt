---------------------------------------------------------
             �:  D3D9 antilag v1.01 :�
---------------------------------------------------------

D3D9 antilag helps to reduce input lag (esp. with the mouse)
in Direct3D 9 games by limiting the amount of frames that
are rendered ahead by the video card. It can also limit
the framerate for smoother gameplay and reduced cpu/gpu
utilization.

To install, put the d3d9.dll and antilag.cfg to the game
executable directory.

The antilag.cfg contains two configuration parameters:

RenderAheadLimit: This is the amount of frames that D3D9
is allowed to 'render ahead'. A value of 1 means that the
render queue is flushed immediately when a frame is ready.
This provides minimal latency, but can cause a significant
performance drop. A value of 2 allows one frame to be in
the queue, which provides a good compromise between low
latency and good performance. Setting of 0 will disable
the feature.

FPSlimit: This setting will limit the framerate to the
rate set. In cases where the framerate is fluctuating alot
limiting the framerate to a lower value (ie. 35) can provide
smoother gameplay feel. It can also be used to reduce the
cpu/gpu usage, which is helpful for laptop users.


During gameplay, holding down the application key* will
disable the render ahead limit. You can use this to test
the antilag functionality. (While moving the mouse in game,
press and hold the app key and compare the apparent latency)

* The application key is the key located between the right
ctrl and windows key.


---------------------------------------------------------
  credits
---------------------------------------------------------

made by Kegetys, http://www.kegetys.net


---------------------------------------------------------
  license & disclaimer
---------------------------------------------------------

You are permitted to install and use this software for 
personal entertainment purposes only. Any commercial,
military or educational use is strictly forbidden without
permission from the author. 

You are free to distribute this software as you wish, as 
long as it is kept 100% free of charge, it is not modified 
in any way and this readme file is distributed with it.

The author takes no responsibility for any damages this 
program may cause, use at your own risk.

---------------------------------------------------------